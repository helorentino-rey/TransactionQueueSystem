/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
//for reference
package queue;

import java.util.List;
import java.util.ArrayList;


/**
 *
 * @author Administrator
 */
public class Queue {

    private int SIZE = 50;
    private int length = 0;
    private String[] items = new String[SIZE];
    private int front, rear;

    public Queue() {
        front = -1;
        rear = -1;
    }

    // check if the queue is full
    public boolean isFull() {
        return front == 0 && rear == SIZE - 1;
    }

    public void expand() {
        String[] newItems = new String[SIZE + (SIZE / 4)];
        System.arraycopy(items, 0, newItems, 0, items.length);
        SIZE = newItems.length;
        items = newItems;
    }

    // check if the queue is empty
    public boolean isEmpty() {
        return front == -1;
    }

    // insert elements to the queue
    public void enQueue(String element) {

        // if queue is full
        if (isFull()) {
            expand();
        } else {
            if (front == -1) {
                // mark front denote first element of queue
                front = 0;
            }

            rear++;
            length++;
            // insert element at the rear
            items[rear] = element;
            System.out.println("Insert " + element);
        }
    }

    // delete element from the queue
    public String deQueue() {
        String element;

        // if queue is empty
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return ("");
        } else {
            // remove element from the front of queue
            element = items[front];

            // if the queue has only one element
            if (front >= rear) {
                front = -1;
                rear = -1;
            } else {
                // mark next element as the front
                front++;
            }
            length--;
            System.out.println(element + " Deleted");
            return element;
        }
    }

    public List<String> getAllElements() {
        List<String> list = new ArrayList<>();
        System.out.println(length);
        if (length == 0) {

            return list;
        }
        for (int i = front; i <= rear; i++) {
            list.add(items[i]);
        }
        return list;
    }
    // display element of the queue

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        if (length == 0) {
            return "[]";
        }

        StringBuilder sb = new StringBuilder();

        sb.append("[");

        for (int i = front; i <= rear; i++) {

            if (items[i] == null) {
                break;
            }

            sb.append(items[i]).append(", ");
        }
        if (length != 0) {
            sb.delete(sb.length() - 2, sb.length());
        }

        sb.append("]");
        return sb.toString();
    }

}
