package queue;

public class DataRecord { // records the information of the user

    private String firstName;
    private String lastName;
    private String password;
    private String email;
    private String birthDate;

    public DataRecord() {
        firstName = "";
        lastName = "";
        password = "";
        email = "";
        birthDate = "";
    }

    public void SetRecord(String firstName, String lastName, String password, String email, String birthDate) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.password = password;
        this.email = email;
        this.birthDate = birthDate;
    }

    public void SetNewValue(int index, String newValue) {
        switch (index) {
            case 0:
                firstName = newValue;
            case 1:
                lastName = newValue;
            case 2:
                password = newValue;
            case 3:
                email = newValue;
            case 4:
                birthDate = newValue;
        }
    }

    public String GetAlumnusValue(int index) {
        switch (index) {
            case 0:
                return firstName;
            case 1:
                return lastName;
            case 2:
                return password;
            case 3:
                return email;
            case 4:
                return birthDate;
            default:
                break;
        }
        return "";
    }

    public void PrintUserRecords() {
        System.out.println(firstName);
        System.out.println("------------------------");
        System.out.println(lastName);
        System.out.println(password);
        System.out.println(email);
        System.out.println(birthDate);
    }
}
